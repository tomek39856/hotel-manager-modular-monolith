package com.github.tomek39856.hotel.manager.availability.api;

import com.github.tomek39856.hotel.manager.availability.RoomType;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class RoomAvailabilityRestController {
    public List<RoomType> getAvailableRoomTypes() {
        
    }
}
