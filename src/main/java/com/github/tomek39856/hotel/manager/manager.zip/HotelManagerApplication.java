package com.github.tomek39856.hotel.manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(HotelManagerApplication.class, args);
    }
}
