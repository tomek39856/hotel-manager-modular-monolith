package com.github.tomek39856.hotel.manager.availability;

class RoomRepository {
}
