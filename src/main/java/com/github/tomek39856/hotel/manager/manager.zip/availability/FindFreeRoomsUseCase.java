package com.github.tomek39856.hotel.manager.availability;

import org.springframework.stereotype.Service;

@Service
public class FindFreeRoomsUseCase {
    private final RoomRepository roomRepository;

    public FindFreeRoomsUseCase(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }
}
