package com.github.tomek39856.hotel.manager.availability;

import java.util.UUID;

public class Room {
    private String id = UUID.randomUUID().toString(); // bez znaczenia - roomTypeHold lapie pierwszy pokoj danego typu
    private RoomType roomType;
}
